test = {   'name': 'q42',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> proportion_in_20th_century == 0.684\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> proportion_in_21st_century == 0.316\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
