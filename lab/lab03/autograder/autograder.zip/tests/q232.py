test = {   'name': 'q232',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> # It looks like you're not making an array.  You shouldn't need to;\n"
                                               '>>> # use .item anywhere in your solution.;\n'
                                               '>>> type(total_charges) == np.ndarray\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
