test = {   'name': 'q214',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(collection_times) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(collection_times) == 744\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> all(collection_times == np.arange(0, 31*24*60*60, 60*60))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
