test = {   'name': 'q33',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> sorted(farmers_markets_locations.labels) == ['MarketName', 'State', 'city', 'x', 'y']\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> farmers_markets_locations.num_rows == 8546\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
