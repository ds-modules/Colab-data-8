test = {   'name': 'q1_21',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> type(clt_applies) == bool and type(residuals_normal) == bool\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
