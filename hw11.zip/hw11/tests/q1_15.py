test = {   'name': 'q1_15',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> all([type(career_length_residual_corr) == int, type(salary_residual_corr) == int])\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
